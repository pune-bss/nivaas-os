import React, { useMemo, useState } from 'react';
import { Calculator, Landmark, FileText, MessageCircle } from 'lucide-react';
import { formatINR, buildWhatsAppUrl, isValidIndianPhone } from '../utils/india';

const card = 'rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 p-5';
const input =
  'w-full rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-950 px-3 py-2 text-sm';

function Num({ label, value, set, step = 1 }: { label: string; value: number; set: (n: number) => void; step?: number }) {
  return (
    <label className="block text-sm">
      <span className="text-slate-600 dark:text-slate-400">{label}</span>
      <input type="number" min={0} step={step} className={input} value={value}
        onChange={(e) => set(Math.max(0, Number(e.target.value) || 0))} />
    </label>
  );
}

function Row({ k, v, bold }: { k: string; v: string; bold?: boolean }) {
  return (
    <div className={`flex justify-between py-1.5 text-sm ${bold ? 'font-semibold border-t border-slate-200 dark:border-slate-800 mt-1 pt-2' : ''}`}>
      <span className="text-slate-600 dark:text-slate-400">{k}</span><span>{v}</span>
    </div>
  );
}

const emiOf = (p: number, rate: number, years: number) => {
  const n = years * 12, r = rate / 1200;
  if (!p || !n) return 0;
  return r === 0 ? p / n : (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
};

const TEMPLATES: Record<string, string> = {
  'First contact': 'Hello {name}, this is {agent}. Thank you for your interest in {project}. When is a good time to talk about your requirements?',
  'Site visit reminder': 'Hi {name}, a reminder of your site visit to {project} tomorrow. Please reply YES to confirm. - {agent}',
  'Follow-up': 'Hi {name}, following up on {project}. Shall I share the price list and payment plan? - {agent}',
  'Payment due': 'Dear {name}, your next payment milestone for {project} is due soon. Please contact {agent} for details.',
};

export function ToolsPage() {
  // EMI + eligibility
  const [price, setPrice] = useState(7500000);
  const [down, setDown] = useState(20);
  const [rate, setRate] = useState(8.75);
  const [years, setYears] = useState(20);
  const [income, setIncome] = useState(100000);
  const [existing, setExisting] = useState(0);

  const loan = price * (1 - down / 100);
  const emi = useMemo(() => emiOf(loan, rate, years), [loan, rate, years]);
  const maxEmi = Math.max(0, income * 0.5 - existing);
  const r = rate / 1200, n = years * 12;
  const eligible = r === 0 ? maxEmi * n : (maxEmi * (Math.pow(1 + r, n) - 1)) / (r * Math.pow(1 + r, n));

  // Cost sheet
  const [area, setArea] = useState(1000);
  const [psf, setPsf] = useState(7000);
  const [plc, setPlc] = useState(150000);
  const [parking, setParking] = useState(300000);
  const [gst, setGst] = useState(5);
  const [sd, setSd] = useState(6);
  const [reg, setReg] = useState(1);
  const base = area * psf, extras = plc + parking, gstAmt = ((base + extras) * gst) / 100;
  const agreement = base + extras;
  const sdAmt = (agreement * sd) / 100, regAmt = (agreement * reg) / 100;
  const total = agreement + gstAmt + sdAmt + regAmt;

  // WhatsApp templates
  const [tpl, setTpl] = useState('First contact');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [agent, setAgent] = useState('');
  const [project, setProject] = useState('');
  const msg = TEMPLATES[tpl].replace('{name}', name || '___').replace('{agent}', agent || '___').replace('{project}', project || '___');
  const phoneOk = isValidIndianPhone(phone);

  return (
    <div className="space-y-6 max-w-6xl">
      <div>
        <h1 className="text-2xl font-semibold">Sales toolkit</h1>
        <p className="text-sm text-slate-600 dark:text-slate-400">Quote a customer in under a minute: EMI, loan eligibility, cost sheet and ready WhatsApp messages.</p>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className={card}>
          <h2 className="flex items-center gap-2 font-semibold mb-4"><Calculator className="w-4 h-4" /> Home loan EMI and eligibility</h2>
          <div className="grid grid-cols-2 gap-3">
            <Num label="Property price (₹)" value={price} set={setPrice} step={50000} />
            <Num label="Down payment (%)" value={down} set={(v) => setDown(Math.min(100, v))} />
            <Num label="Interest rate (% p.a.)" value={rate} set={setRate} step={0.05} />
            <Num label="Tenure (years)" value={years} set={(v) => setYears(Math.min(30, v))} />
          </div>
          <div className="mt-4">
            <Row k="Loan amount" v={formatINR(loan)} />
            <Row k="Monthly EMI" v={formatINR(Math.round(emi))} bold />
            <Row k="Total interest" v={formatINR(Math.round(emi * years * 12 - loan))} />
            <Row k="Total payable" v={formatINR(Math.round(emi * years * 12))} />
          </div>
          <div className="grid grid-cols-2 gap-3 mt-5">
            <Num label="Monthly income (₹)" value={income} set={setIncome} step={5000} />
            <Num label="Existing EMIs (₹)" value={existing} set={setExisting} step={1000} />
          </div>
          <div className="mt-3">
            <Row k="EMI the customer can afford (50% of income)" v={formatINR(Math.round(maxEmi))} />
            <Row k="Estimated eligible loan" v={formatINR(Math.round(eligible))} bold />
            <p className="text-xs text-slate-500 mt-2">{loan <= eligible ? 'The requested loan is within the estimate.' : 'The requested loan is above the estimate. Suggest a higher down payment or a co-applicant.'} Banks decide the final amount.</p>
          </div>
        </section>

        <section className={card}>
          <h2 className="flex items-center gap-2 font-semibold mb-4"><FileText className="w-4 h-4" /> Cost sheet</h2>
          <div className="grid grid-cols-2 gap-3">
            <Num label="Area (sq ft)" value={area} set={setArea} />
            <Num label="Rate (₹ per sq ft)" value={psf} set={setPsf} step={100} />
            <Num label="Floor rise / PLC (₹)" value={plc} set={setPlc} step={10000} />
            <Num label="Parking (₹)" value={parking} set={setParking} step={10000} />
            <Num label="GST (%)" value={gst} set={setGst} step={0.5} />
            <Num label="Stamp duty (%)" value={sd} set={setSd} step={0.5} />
            <Num label="Registration (%)" value={reg} set={setReg} step={0.5} />
          </div>
          <div className="mt-4">
            <Row k="Base price" v={formatINR(base)} />
            <Row k="PLC + parking" v={formatINR(extras)} />
            <Row k={`GST (${gst}%)`} v={formatINR(Math.round(gstAmt))} />
            <Row k={`Stamp duty (${sd}%)`} v={formatINR(Math.round(sdAmt))} />
            <Row k={`Registration (${reg}%)`} v={formatINR(Math.round(regAmt))} />
            <Row k="All-in cost" v={formatINR(Math.round(total))} bold />
          </div>
          <p className="text-xs text-slate-500 mt-2">Stamp duty and registration differ by state and buyer. Check current rates before quoting.</p>
        </section>
      </div>

      <section className={card}>
        <h2 className="flex items-center gap-2 font-semibold mb-4"><MessageCircle className="w-4 h-4" /> WhatsApp templates</h2>
        <div className="grid gap-3 md:grid-cols-4">
          <label className="block text-sm"><span className="text-slate-600 dark:text-slate-400">Template</span>
            <select className={input} value={tpl} onChange={(e) => setTpl(e.target.value)}>
              {Object.keys(TEMPLATES).map((k) => <option key={k}>{k}</option>)}
            </select></label>
          <label className="block text-sm"><span className="text-slate-600 dark:text-slate-400">Customer name</span>
            <input className={input} value={name} onChange={(e) => setName(e.target.value)} /></label>
          <label className="block text-sm"><span className="text-slate-600 dark:text-slate-400">Customer phone</span>
            <input className={input} inputMode="tel" placeholder="98XXXXXXXX" value={phone} onChange={(e) => setPhone(e.target.value)} /></label>
          <label className="block text-sm"><span className="text-slate-600 dark:text-slate-400">Your name</span>
            <input className={input} value={agent} onChange={(e) => setAgent(e.target.value)} /></label>
        </div>
        <label className="block text-sm mt-3"><span className="text-slate-600 dark:text-slate-400">Project</span>
          <input className={input} value={project} onChange={(e) => setProject(e.target.value)} /></label>
        <div className="mt-3 rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 p-3 text-sm">{msg}</div>
        <div className="mt-3 flex gap-2">
          <button disabled={!phoneOk} onClick={() => window.open(buildWhatsAppUrl(phone, msg), '_blank', 'noopener')}
            className="rounded-lg bg-emerald-600 text-white px-4 py-2 text-sm disabled:opacity-50">Send on WhatsApp</button>
          <button onClick={() => navigator.clipboard?.writeText(msg)}
            className="rounded-lg border border-slate-300 dark:border-slate-700 px-4 py-2 text-sm">Copy message</button>
        </div>
        {!phoneOk && phone && <p className="text-xs text-red-600 mt-2">Enter a valid 10-digit Indian mobile number.</p>}
      </section>
    </div>
  );
}
