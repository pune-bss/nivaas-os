# Publish NivaasOS for free (Firebase Hosting, Spark plan)

Your app already uses Firebase, so Firebase Hosting is the simplest free option.

## One-time setup
1. Install Node.js 20+ from nodejs.org
2. In this folder run: `npm install`   (a .npmrc is included so the dependency conflict is handled)
3. `npm install -g firebase-tools` then `firebase login`
4. `firebase use virtual-outrider-86pck`   (your project ID from firebase-applet-config.json)

## Build and publish
```
npm run build
firebase deploy --only hosting,firestore:rules,firestore:indexes
```
Your site goes live at https://virtual-outrider-86pck.web.app

## Required in the Firebase console
- Authentication > Sign-in method: enable Email/Password (and Google if used)
- Authentication > Settings > Authorized domains: add your .web.app domain and any custom domain
- Firestore: confirm the database "ai-studio-d4bd18c9-..." exists (firebase.json now points to it)

## Free-plan limits (Spark)
- Hosting: 10 GB storage, ~360 MB/day transfer
- Firestore: 1 GiB, 50K reads and 20K writes per day
- Cloud Functions (company approval, invites, scheduled jobs) need the Blaze pay-as-you-go plan.
  Without it, deploy only hosting and rules as above; features that call Functions won't work.
- Cloud Storage for new projects may require Blaze. Check the console; document upload needs it.

## Free alternatives for the frontend
Netlify, Vercel or Cloudflare Pages: connect a GitHub repo, build command `npm run build`,
output folder `dist`. Add a rewrite of /* to /index.html. Still add that domain to
Firebase Authorized domains.

## Before real customers
- Rotate nothing: Firebase web API keys are public by design, but restrict the key to your domain
  in Google Cloud Console > Credentials.
- Test firestore.rules with the emulator (see TESTING_AND_SECURITY.md).
